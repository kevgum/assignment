# hotel.py

def calculate_cost(room_type, days):
    """
    Calculate total cost for a booking based on room type and number of days.
    Feature-X: Added luxury room option with special pricing.
    Feature-Y: Added budget room option and discount functionality.
    Feature-Z: Added premium suite option with enhanced amenities.
    """
    prices = {
        "single": 2000,
        "double": 3500,
        "bed_and_breakfast": 4000,
        "with_kitchen": 4500,
        "exclusive": 6000,
        "economy": 1500,
        "luxury": 9500,  # Feature-Z: Changed price for luxury room (different from feature-x and feature-y)
        "budget": 1000,
        "premium_suite": 10000
    }
    return prices.get(room_type, 0) * days


def print_booking_summary(room_type, days):
    """
    Print a summary of the booking with total cost.
    """
    cost = calculate_cost(room_type, days)
    print(f"You booked a {room_type.replace('_', ' ')} room for {days} day(s). Total: KES {cost}")


def main():
    """
    Main entry point for the application.
    Used by Maven and setuptools entry points.
    """
    import argparse
    import sys

    room_types = [
        "single", "double", "bed_and_breakfast", "with_kitchen", "exclusive",
        "economy", "luxury", "budget", "premium_suite"
    ]

    parser = argparse.ArgumentParser(description="Hotel Room Booking System")
    parser.add_argument("room_type", nargs="?", choices=room_types, help="Type of room to book")
    parser.add_argument("days", nargs="?", type=int, help="Number of days to stay")
    args = parser.parse_args()

    room_type = args.room_type
    days = args.days

    if room_type is None:
        print("Available room types:")
        for rt in room_types:
            print(f"- {rt}")
        room_type = input("Enter room type: ").strip()
        while room_type not in room_types:
            print("Invalid room type. Please choose from the list above.")
            room_type = input("Enter room type: ").strip()

    if days is None:
        while True:
            try:
                days = int(input("Enter number of days: ").strip())
                if days > 0:
                    break
                else:
                    print("Number of days must be positive.")
            except ValueError:
                print("Please enter a valid integer for days.")

    print_booking_summary(room_type, days)


if __name__ == "__main__":
    main()
